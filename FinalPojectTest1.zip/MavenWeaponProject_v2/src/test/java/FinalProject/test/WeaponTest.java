package FinalProject.test;

import FinalProjectTest.models.Weapon;
import FinalProjectTest.models.LivingBeing;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class WeaponTest {

    @Test
    public void testCheckCollisionNearby() {
        LivingBeing target = new LivingBeing(5, 5);
        Weapon weapon = new Weapon(10, 10); // distancia ≈ 7.07 < 10
        assertTrue(weapon.checkCollision(target));
    }

    @Test
    public void testCheckCollisionFar() {
        LivingBeing target = new LivingBeing(100, 100);
        Weapon weapon = new Weapon(0, 0); // distancia muy grande
        assertFalse(weapon.checkCollision(target));
    }
}
