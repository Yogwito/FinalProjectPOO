package FinalProjectTest.models;

public class LivingBeing {
    private int x;
    private int y;

    public LivingBeing(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
