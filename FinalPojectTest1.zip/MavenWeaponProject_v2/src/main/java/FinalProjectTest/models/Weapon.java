package FinalProjectTest.models;

public class Weapon {
    private int x;
    private int y;
    private int collisionRadius = 10;

    public Weapon(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public boolean checkCollision(LivingBeing target) {
        int dx = this.x - target.getX();
        int dy = this.y - target.getY();
        double distance = Math.sqrt(dx * dx + dy * dy);
        return distance <= collisionRadius;
    }
}
