package FinalProjectTest2.test;

import FinalProjectTest2.models.Monster;
import FinalProjectTest2.utils.DamageManager;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DamageManagerTest {

    @Test
    public void testAplicarDanio() {
        Monster m = new Monster(100, 10);
        DamageManager d = new DamageManager();
        d.aplicarDanio(m, 25);
        assertEquals(75, m.getHealth());
    }
}
