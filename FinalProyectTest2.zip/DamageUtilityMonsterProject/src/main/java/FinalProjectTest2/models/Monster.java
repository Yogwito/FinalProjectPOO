package FinalProjectTest2.models;

public class Monster {
    private int health;
    private int damage;

    public Monster(int health, int damage) {
        this.health = health;
        this.damage = damage;
    }

    public int getHealth() {
        return health;
    }

    public void recibirDanio(int cantidad) {
        this.health -= cantidad;
    }
}
