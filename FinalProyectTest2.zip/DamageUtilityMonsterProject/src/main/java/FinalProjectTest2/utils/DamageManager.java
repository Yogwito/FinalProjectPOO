package FinalProjectTest2.utils;

import FinalProjectTest2.models.Monster;

public class DamageManager {
    public void aplicarDanio(Monster objetivo, int danio) {
        objetivo.recibirDanio(danio);
    }
}
